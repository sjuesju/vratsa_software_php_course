<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="function.php" method="POST">
        <h3>Input Array:</h3>
        <p>Избройте числата разделени с запетая</p>
        <input type="text" name='array'>
        <h3>Input number:</h3>
        <input type="text" name='n'>
        <input type="submit" value="Submit">
    </form>
</body>
</html>