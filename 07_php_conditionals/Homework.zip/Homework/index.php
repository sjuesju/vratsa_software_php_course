<!DOCTYPE html>
<html lang="bg-Bg">
<head>
	<title>Домашно за PHP Conditionals</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<body>
	<div id="container">
		<div id="header">
			<h1>Домашно</h1>
			<h4>по PHP Conditionals</h4> 
		</div>
		<div id="header_bottom_dot">
		</div>
		<div id="links">
			<ul>
				<li><a href="tasks/task_1.php">Задача 1</a></li>
				<li><a href="tasks/task_2.php">Задача 2</a></li>
				<li><a href="tasks/task_3.php">Задача 3</a></li>
				<li><a href="tasks/task_4.php">Задача 4</a></li>
			</ul>
		</div>
		<div id="footer">
		</div>
	</div>	
</body>
</html>